/**
 * HomeServices
 *
 * @author      :: Jeff Lee
 * @created     :: 2014/10/11
 */

define(['angular'], function (angular) {

    return angular.module('Home.services', []);

});
