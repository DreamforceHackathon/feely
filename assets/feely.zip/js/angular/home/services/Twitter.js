/**
 * Twitter
 *
 * @author      :: Jeff Lee
 * @created     :: 2014/10/11
 */

define([
    'home/services',
], function (homeServices) {
    'use strict';

    return homeServices

        .factory('Twitter', [function () {
            return {

            };
        }]);
});
